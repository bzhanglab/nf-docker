.onAttach <- function(lib, pkg) {
	 packageStartupMessage("******************************************\n")
	 packageStartupMessage("*            Welcome to NetSAM !         *\n")
	 packageStartupMessage("******************************************\n")
}
