#ifndef __COMMON_H__
#define __COMMON_H__

#define DELETE_EDGE 0
#define DELETE_NOD 1
#define DIRECTED  TRUE
#define UNDIRECTED FALSE
#define MAX_NUM_CLIQUES 40960
//#define _DEBUG 
#define MAX_LINE_LENGTH 1024
#define EPS 1.0e-6

#endif
