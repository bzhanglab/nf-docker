/*
** Copyright (C) 2010 Zhiao Shi, Bing Zhang <zhiao.shi@accre.vanderbilt.edu, bing.zhang@vanderbilt.edu>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "ice.h"

void print_help(char *command){
  printf("Usage: %s [graph_file] [min_clique_weight (multiplier of the # of nodes)]\n", command);
 }

/* return the total degree of the nodes in a graph */
int total_degree(graph_t *g, set_t nodes){
  int size; 
  int i=-1;
  int d=0;
 
  size = set_size(nodes);
  while ((i=set_return_next(nodes,i))>=0) {
    d+=graph_vertex_degree(g,i);
  }
  return d;
}

/* find one maxium clique in graph
 * if multiple maxium cliques are found, return
 * the one with the lowest total degree 
 * if there are more than one such cliques, select the one that is 
 * found first.
 * 
 * return: the found clique
 */
set_t clique_single_maximum_ld(graph_t *g){
  set_t *cliques;
  int num; 
  clique_options *opt;
  int i;
  int lowest_d, cur_index, cur_d;

  cliques = (set_t *)malloc(sizeof(set_t)*MAX_NUM_CLIQUES);
  /* initialize opt */
  opt = (clique_options *)malloc(sizeof(clique_options));
  opt->reorder_function=reorder_by_default;
  opt->reorder_map=NULL;
  opt->time_function=NULL;
  opt->output=NULL;
  opt->user_function=NULL;
  opt->user_data=NULL;
  opt->clique_list = cliques;
  opt->clique_list_length=MAX_NUM_CLIQUES;

   /* find all maxium cliques */
  num=clique_find_all(g,0,0,TRUE,opt);
/*  DEBUG("num=%d\n",num); */
#ifdef _DEBUG
  for(i=0;i<num;i++)
    set_print(cliques[i]);
#endif
 lowest_d=INT_MAX;
 cur_index=-1;
 if(num>1){
   for(i=0;i<num;i++){
	  cur_d = total_degree(g,cliques[i]);
	DEBUG("clique %d has total degree of %d \n", i, cur_d);
	  if(cur_d<lowest_d){
		lowest_d = cur_d;
		cur_index=i; 
	  } 
   }
	DEBUG("clique %d has the lowest total degree of %d \n", cur_index, lowest_d);
	return cliques[cur_index];
 }
 else{
   return cliques[0];
 }
}

/* store "clique" to the list of cliques 
 *
 */
int store_all_cliques(graph_t *g, set_t **cliques, set_t clique, int size){
  int cur_size;
  set_t *new_cliques; 
  
  cur_size = size+1;
  DEBUG("cur_size=%d\n",cur_size);
  new_cliques=(set_t *)realloc(*cliques, sizeof(set_t)*(cur_size+1));   
  new_cliques[cur_size-1]=set_duplicate(clique);  
  print_nodes(g, new_cliques[cur_size-1]);
  fflush(stdout);
  new_cliques[cur_size]=NULL;  
  *cliques=new_cliques; 
  return cur_size;
}


int clique_weight(graph_t *g, set_t clique){
  int i=-1; 
  int weight=0;

  while ((i=set_return_next(clique,i))>=0) {
    /* printf("weight = %d\n", g->weights[i]); */
    weight += g->weights[i];
  }
  return weight;
}

void set_clique_weight(graph_t *g, set_t clique,int new_weight){
  int i=-1;
  while ((i=set_return_next(clique,i))>=0) {
    g->weights[i]=new_weight;
  }
}

/* find all relatively independent maximal weighted cliques */
set_t *find_riml_wc(graph_t *g, int new_weight, int minweight){
  set_t **maximum_cliques;
  set_t clique;
  int cur_weight;
  int num_clique_found=0;

  maximum_cliques=(set_t **)malloc(sizeof(set_t *));
  *maximum_cliques=NULL;
  clique=clique_single_maximum_ld(g);
  cur_weight=clique_weight(g,clique);
  #ifdef _DEBUG
  printf("cur_weight=%d\n",cur_weight);
  #endif
  do{
    num_clique_found=store_all_cliques(g, maximum_cliques, clique, num_clique_found);
    set_clique_weight(g,clique,new_weight);
    clique=clique_single_maximum_ld(g);
    cur_weight=clique_weight(g,clique);
    #ifdef _DEBUG
    printf("cur_weight=%d\n",cur_weight); 
	printf("num_clique_found is %d\n", num_clique_found); 
	#endif
  } while((cur_weight >= minweight) && (num_clique_found < MAX_NUM_CLIQUES));
  return *maximum_cliques;
}

/*
 * find all pseudo cliques in the original graph 
 * 
 return a set of sets
 each set is a  maximum clique in induced graph during each step  
 */ 
set_t *find_all_pseudo_cliques(graph_t *g, int delete_edge_or_node, int minsize){
  int cur_size=INT_MAX; 
  set_t **maximum_cliques;
  set_t **maximal_cliques;
  int cur_num = 0;  /* number of cliques found */
  int new_num;
  graph_t *new_g=NULL;
  //set_t clique,new_clique; 
  set_t clique; 

  maximum_cliques=(set_t **)malloc(sizeof(set_t *));
  maximal_cliques=(set_t **)malloc(sizeof(set_t *));

  *maximum_cliques = NULL;
  *maximal_cliques = NULL;

  DEBUG("sizeof(set_t) = %ld\n", sizeof(set_t));

  clique=clique_single_maximum_ld(g);
  DEBUG("ok\n");
  new_num=store_all_cliques(g, maximum_cliques, clique, cur_num); 
  DEBUG("ok\n");
  store_all_cliques(g, maximal_cliques, clique, cur_num);

  while(cur_size > minsize){
  #ifdef _DEBUG
	set_print(clique);
  #endif
	clique=clique_single_maximum_ld(new_g);
  #ifdef _DEBUG
	set_print(clique);
  #endif
    cur_size=set_size(clique);
    DEBUG("cur_size is %d\n", cur_size);
    cur_num = new_num;
    new_num =store_all_cliques(g, maximum_cliques, clique, cur_num); 
  #ifdef _DEBUG
    set_print((*maximum_cliques)[0]); 
    set_print((*maximum_cliques)[1]); 
    set_print((*maximal_cliques)[0]); 
  #endif
    graph_free(new_g);
    set_free(clique);
    exit(0);
  } 
  return NULL;
}
