/*
** Copyright (C) 2010 Zhiao Shi, Bing Zhang <zhiao.shi@accre.vanderbilt.edu, bing.zhang@vanderbilt.edu>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef __CLIQ_H__
#define __CLIQ_H__

#include "cliquer.h"
#include "common.h"

void print_help(char *command);
set_t *find_all_pseudo_cliques(graph_t *g, int delete_edge_or_node, int minsize);
set_t clique_single_maximum_ld(graph_t *g);
int total_degree(graph_t *g, set_t nodes);
int store_all_cliques(graph_t *g, set_t ** cliques, set_t clique, int cur_num);
set_t *find_riml_wc(graph_t *g, int newweight,int minweight);

/* Logging relies on the time library */
#include <sys/time.h>

/* maximum file name size */
#define MAX_FN_SIZE 64
#define MAX_LN_SIZE 5012

/* A handy little macro to force logging */
#define LOG(...) \
        { \
          struct timeval tick; \
          gettimeofday(&tick, NULL); \
          fprintf(stdout, "%i.%i - ", tick.tv_sec, tick.tv_usec); \
          fprintf(stdout, __VA_ARGS__); fflush(stdout); \
      }

/* A handy little macto to force error logging */
#define ERR(...) \
        { \
          struct timeval tick; \
          gettimeofday(&tick, NULL); \
          fprintf(stderr, "%i.%i - ", tick.tv_sec, tick.tv_usec); \
          fprintf(stderr, __VA_ARGS__); fflush(stderr); \
        }

/* A handy little macro to force debug logging */
#ifdef _DEBUG
/*#define DEBUG(...) \
        { \
          struct timeval tick; \
          gettimeofday(&tick, NULL); \
          fprintf(stdout, "%i.%i - ", tick.tv_sec, tick.tv_usec); \
          fprintf(stdout, __VA_ARGS__); fflush(stdout); \
        }
*/
#define DEBUG(...) \
        { \
          fprintf(stdout, "%s(%d):", __FILE__, __LINE__); \
          fprintf(stdout, __VA_ARGS__); fflush(stdout); \
        }
#else
#define DEBUG(...)
#endif


#endif
