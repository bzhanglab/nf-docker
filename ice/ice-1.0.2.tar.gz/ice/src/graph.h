/*
** Copyright (C) 2010 Zhiao Shi, Bing Zhang <zhiao.shi@accre.vanderbilt.edu, bing.zhang@vanderbilt.edu>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef CLIQUER_GRAPH_H
#define CLIQUER_GRAPH_H

#include"set.h"
#include <glib.h> 
#include "common.h"

typedef struct _graph_t graph_t;
/*TODO*/
typedef int nodweight_t;

struct _graph_t {
    boolean_t is_directed;
	int n;             /* Vertices numbered 0...n-1 */
	set_t *edges;      /* A list of n sets (the edges). */
    GHashTable *nodemap; /* node name -> id  */
    GHashTable *r_nodemap; /* id-> node name */
	int *weights;      /* A list of n vertex weights. */
    GHashTable *edgemap; /* edge name (a string) "node_id1-node_id2" -> edge_id */
    GHashTable *r_edgemap; /* edge_id -> edge name (a string) "node_id1-node_id2") */
    double *edge_weights; /* A list of edge weights */
};

#define GRAPH_IS_EDGE_FAST(g,i,j)  (SET_CONTAINS_FAST((g)->edges[(i)],(j)))
#define GRAPH_IS_EDGE(g,i,j) (((i)<((g)->n))?SET_CONTAINS((g)->edges[(i)], \
							  (j)):FALSE)
#define GRAPH_ADD_EDGE(g,i,j) do {            \
	SET_ADD_ELEMENT((g)->edges[(i)],(j)); \
	SET_ADD_ELEMENT((g)->edges[(j)],(i)); \
} while (FALSE)
#define GRAPH_DEL_EDGE(g,i,j) do {            \
	SET_DEL_ELEMENT((g)->edges[(i)],(j)); \
	SET_DEL_ELEMENT((g)->edges[(j)],(i)); \
} while (FALSE)

void print_nodes(graph_t *g, set_t nodes);
int name2node(graph_t *g, char *name);
char *node2name(graph_t *g, int id);
set_t nodes_with_degree_le(graph_t *g, int degree);
graph_t *graph_read(char *file, int n, int init_node_weight, boolean_t is_directed);
boolean_t parse_line(char *line, graph_t *g, int init_node_weight,  boolean_t is_directed, int *cur_node_id, int *cur_edge_id);
unsigned int graph_size(char *file);
graph_t *graph_duplicate(graph_t *g);      
int clique_weight(graph_t *g, set_t clique);
void set_clique_weight(graph_t *g,set_t clique,int new_weight);

/******/
extern graph_t *graph_new(int n, boolean_t is_directed);
extern void graph_free(graph_t *g);
extern void graph_resize(graph_t *g, int size);
extern void graph_crop(graph_t *g);

extern boolean_t graph_weighted(graph_t *g);
extern int graph_edge_count(graph_t *g, boolean_t is_directed);

extern graph_t *graph_read_dimacs(FILE *fp);
extern graph_t *graph_read_dimacs_file(char *file);
extern boolean_t graph_write_dimacs_ascii(graph_t *g, char *comment,FILE *fp);
extern boolean_t graph_write_dimacs_ascii_file(graph_t *g,char *comment,
					     char *file);
extern boolean_t graph_write_dimacs_binary(graph_t *g, char *comment,FILE *fp);
extern boolean_t graph_write_dimacs_binary_file(graph_t *g, char *comment,
					      char *file);

extern void graph_print(graph_t *g);
extern boolean_t graph_test(graph_t *g, FILE *output);
extern int graph_test_regular(graph_t *g);

UNUSED_FUNCTION INLINE
static int graph_subgraph_weight(graph_t *g,set_t s) {
	int i,j;
	int count=0;
	setelement e;

	for (i=0; i<SET_ARRAY_LENGTH(s); i++) {
		if (s[i]) {
			e=s[i];
			for (j=0; j<ELEMENTSIZE; j++) {
				if (e&1)
					count+=g->weights[i*ELEMENTSIZE+j];
				e = e>>1;
			}
		}
	}
	return count;
}

UNUSED_FUNCTION INLINE
static int graph_vertex_degree(graph_t *g, int v) {
	return set_size(g->edges[v]);
}

#endif /* !CLIQUER_GRAPH_H */
