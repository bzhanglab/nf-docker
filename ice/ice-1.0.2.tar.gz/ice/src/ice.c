/*
** Copyright (C) 2010 Zhiao Shi, Bing Zhang <zhiao.shi@accre.vanderbilt.edu, bing.zhang@vanderbilt.edu>
**  
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
** 
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
** 
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software 
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "ice.h"

int main(int argc, char **argv){
  graph_t *g;
  int min_weight, new_weight;
  set_t *cliques;
  int n;
  int min_cliq_weight; /* multiplier of the number of nodes*/
  if(argc<3){
	print_help(argv[0]);
	exit(1);
  }
  
  n=graph_size(argv[1]);
  min_cliq_weight=atoi(argv[2]);
  if(min_cliq_weight<1){
    printf("min_cliq_weight must >= 1\n");
	exit(1);
  }
  /* set initial node weight to the total number of nodes */
  g=graph_read(argv[1], n, n, UNDIRECTED);
  DEBUG("read done\n");

  min_weight=n*min_cliq_weight;
  new_weight=1;
  /* the node weight will be modified */
  cliques=find_riml_wc(g,new_weight, min_weight);
  #ifdef _DEBUG
   printf("the total weight is %d\n", clique_weight(g,cliques[0]));
  #endif
  graph_free(g);
  return 0;
}
